export const config = {
  appName: 'MyApp',
  version: '1.0',
  author: 'Rahul Jadhav'
};

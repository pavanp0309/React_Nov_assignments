


export function add(a, b) {
    return a + b;
}

export function subtract(a, b) {
    return a - b;
}


export function sum(a, b) { return a + b; }
export function difference(a, b) { return a - b; }

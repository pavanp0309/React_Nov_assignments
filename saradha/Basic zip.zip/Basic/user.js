let userName = '';

export function setUser(name) {
  userName = name;
}

export function getUser() {
  return userName;
}

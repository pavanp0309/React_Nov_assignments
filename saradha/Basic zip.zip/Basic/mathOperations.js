export function calculateSum(a, b) {
  return a + b;
}



export default function subtract(a, b) {
  return a - b;
}
export function multiply(a, b) {
  return a * b;
}

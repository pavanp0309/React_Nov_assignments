export function upper(str) { return str.toUpperCase(); }
export function lower(str) { return str.toLowerCase(); }

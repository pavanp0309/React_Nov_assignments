
import { funcA } from './moduleA.js';
export function funcB() {
  console.log('B calls A:');
  // You can optionally call funcA() here.
}
